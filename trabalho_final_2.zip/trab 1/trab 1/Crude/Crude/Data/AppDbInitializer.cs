﻿using Crude.Models;

namespace Crude.Data
{
    public static class AppDbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDbContext>();

                // Garante que o banco de dados existe
                context.Database.EnsureCreated();

                // Adiciona dados ao banco se ele estiver vazio
                if (!context.Fornecedores.Any())
                {
                    context.Fornecedores.AddRange(new List<Fornecedor>
                    {
                        new Fornecedor
                        {
                            RazaoSocial = "Fornecedor 1 LTDA",
                            NomeFantasia = "Fornecedor 1",
                            Email = "contato@fornecedor1.com.br",
                            Telefone = "(16) 5555-66666",
                            EnderecoCompleto = "Rua São Paulo, 123, São Paulo, SP",
                            NomeContato = "Bruno Santos"
                        },
                        new Fornecedor
                        {
                            RazaoSocial = "Fornecedor 2 LTDA",
                            NomeFantasia = "Fornecedor 2",
                            Email = "contato@fornecedor2.com.br",
                            Telefone = "(16) 9876-5432",
                            EnderecoCompleto = "Av. Plinio, 456, 123, São Paulo, SP",
                            NomeContato = "Cynthia"
                        }
                    });

                    context.SaveChanges();
                }
            }
        }
    }
}
